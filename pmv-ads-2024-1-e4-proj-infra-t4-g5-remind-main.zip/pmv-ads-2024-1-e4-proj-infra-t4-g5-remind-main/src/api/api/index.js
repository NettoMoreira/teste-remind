const app = require('../src/app');

module.exports = app;
