export default function NotFound() {
  return (
    <div>
      <h1>404</h1>
      <p>Not Found</p>
    </div>
  );
}
