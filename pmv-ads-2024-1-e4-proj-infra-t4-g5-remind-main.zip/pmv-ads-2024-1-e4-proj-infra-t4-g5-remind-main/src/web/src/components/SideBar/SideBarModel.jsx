import SideBarItem from './SideBarItem';
import SideBarRoot from './SideBarRoot';

export const SideBarModel = {
  Root: SideBarRoot,
  Item: SideBarItem,
};
